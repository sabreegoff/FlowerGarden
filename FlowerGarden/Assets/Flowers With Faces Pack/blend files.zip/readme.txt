For the .blend files to load the textures correctly, please place all the .blend files in the same folder as the texture file (flowers.png).

- Ripple Game Art
ripplegameart@gmail.com